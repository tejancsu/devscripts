<!-- Please check if a similar issue already exists or has been closed before before opening your issue. -->

### Description
<!-- Provide a general description of the bug or feature -->

### Expected behavior

<!-- What you expected to happen -->

### Actual behavior

<!-- What actually happened -->

### Steps to Reproduce

1. [First Step]
2. [Second Step]
3. [and so on...]

### Versions

  - Prezto commit:
  - ZSH version:
  - OS information:

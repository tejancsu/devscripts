
# # Run the apps.
# disco-reco() {
#     kill -9 $(ps -ef | grep java | grep reco-service | awk '{print $2}')
#     sleep 1
#     mkdir ~/logs &>> /dev/null
#     nohup java -Xms6g -Xmx6g -XX:MaxMetaspaceSize=256m  -XX:+UseG1GC -Xss256k -XX:+UnlockExperimentalVMOptions -XX:G1NewSizePercent=10 -XX:G1MaxNewSizePercent=75 -Dfile.encoding=UTF8 -Xdebug -Xrunjdwp:transport=dt_socket,server=y,suspend=n,address=5005 -cp /Users/ts_24/its-apps-discovery/reco-apps/reco-service/.dist/*.jar com.apple.its.disco.recoservice.RecoServiceLauncher >> ~/logs/fuse_reco_service.log 2>&1&
# }

# # Run the data access service.
# disco-das() {
#     kill -9 $(ps -ef | grep java | grep data-access-service | awk '{print $2}')
#     sleep 1
#     nohup java -jar -agentlib:jdwp=transport=dt_socket,server=y,suspend=n,address=5006 -jar /Users/ts_24/its-apps-discovery/reco-apps/data-access-service/.dist/*.jar >> ~/logs/fuse_das.log 2>&1&
# }

# # Run the debugger.
# disco-debugger() {
#     kill -9 $(ps -ef | grep java | grep reco-debugger | awk '{print $2}')
#     sleep 1
#     nohup java -jar /Users/ts_24/its-apps-discovery/reco-apps/reco-debugger/.dist/*.jar -Drio.jetty.static_resources_dir=/Users/ts_24/its-apps-discovery/reco-apps/reco-debugger/src/main/resources/web/ >> ~/logs/fuse_debug.log 2>&1&
# }
# alias-ed commands for starting the recommendation services
video-reco() {
    kill -9 $(ps -ef | grep java | grep video-reco-service | awk '{print $2}')
    sleep 1
    nohup java -Xms8g -Xmx12g -XX:MaxMetaspaceSize=256m  -XX:+UseG1GC -Xss256k -XX:+UnlockExperimentalVMOptions -XX:G1NewSizePercent=10 -XX:G1MaxNewSizePercent=75 -Dfile.encoding=UTF8 -Xdebug -Xrunjdwp:transport=dt_socket,server=y,suspend=n,address=5005 -cp /Users/ts_24/its-apps-discovery/reco-services-video/video-reco-service/.dist/*.jar com.apple.amp.disco.reco.service.RecoServiceLauncher >> ~/logs/video_reco_service.log 2>&1&
}
video-debugger() {
    kill -9 $(ps -ef | grep java | grep video-reco-debugger | awk '{print $2}')
    sleep 1
    nohup java -jar /Users/ts_24/its-apps-discovery/reco-services-video/video-reco-debugger/.dist/*.jar com.apple.amp.disco.reco.service.RecoDebuggerLauncher -Drio.jetty.static_resources_dir=/Users/ts_24/its-apps-discovery/reco-services-video/video-reco-debugger/src/main/resources/web/ >> ~/logs/video_debug.log 2>&1&
}

disco-reco() {
    kill-java-process reco-service
    sleep 1
    nohup java -Xms6g -Xmx6g -XX:MaxMetaspaceSize=256m  -XX:+UseG1GC -Xss256k -XX:+UnlockExperimentalVMOptions -XX:G1NewSizePercent=10 -XX:G1MaxNewSizePercent=75 -Dfile.encoding=UTF8 -Xdebug -Xrunjdwp:transport=dt_socket,server=y,suspend=n,address=5005 -cp /Users/ts_24/its-apps-discovery/reco-apps/reco-service/.dist/*.jar com.apple.its.disco.recoservice.RecoServiceLauncher >> ~/logs/fuse_reco_service.log 2>&1&
}

disco-das() {
    kill-java-process data-access-service
    sleep 1
    nohup java -Xdiag -jar -agentlib:jdwp=transport=dt_socket,server=y,suspend=n,address=5006 -jar /Users/ts_24/its-apps-discovery/reco-apps/data-access-service/.dist/*.jar >> ~/logs/fuse_das.log 2>&1&
}
    
disco-debugger() {
    kill-java-process reco-debugger
    sleep 1
    nohup java -jar /Users/ts_24/its-apps-discovery/reco-apps/reco-debugger/.dist/*.jar -Drio.jetty.static_resources_dir=/Users/ts_24/its-apps-discovery/reco-apps/reco-debugger/src/main/resources/web/ >> ~/logs/fuse_debug.log 2>&1&
}

kill-java-process() {
    echo "killing $1, process-id: $(ps -ef | grep java | grep $1 | awk '{print $2}')"
    kill -9 $(ps -ef | grep java | grep $1 | awk '{print $2}')
}
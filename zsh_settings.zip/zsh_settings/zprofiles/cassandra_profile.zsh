alias 5reco='cqlqa itms5shared20 its_apps_reco'
alias 6reco='cqlqa itms6shared20 its_apps_reco'
alias 7reco='cqlqa itms7shared20 its_apps_reco'
alias 8reco='cqlqa itms8shared20'
alias 8reco2='cqlqa_sharded itms8shared20 its_apps_reco 02'
alias 9reco='cqlqa_sharded itms9shared20 its_apps_reco 01'
alias 9reco2='cqlqa_sharded itms9shared20 its_apps_reco 02'
alias 11reco='cqlqa_sharded itms11shared20 its_apps_reco 01'
alias 11reco2='cqlqa_sharded itms11shared20 its_apps_reco 02'

cqlqa() {
    if [ $# -eq 0 ]
    then
        echo "clusterName required. Try \"cqlqa itms8shared20 keyspace\". keyspace is optional"
        return
    fi

    cluster=$1
    if [ "$cluster" = "itms7shared20" ]
    then
        cluster='itms7shared20_s02'
    fi
    if [ "$cluster" = "itms8shared20" ]
    then
        cluster='itms8shared20'
    fi

    local host=$(cassandraHostFetcher "http://casserole.vp.if1.apple.com/api/v1/cluster_endpoints?appscope=$1&cluster=$cluster&dc=DC1")
    local auth=''
    local keyspace=''
    
    if [ $# -eq 2 ] 
    then 
        keyspace="-k"$2
    fi


    if echo $1 | grep -q "itms5shared20"
    then 
        auth='-u itms5shared20_cassandra_user_admin -p da6ee8b6-de7e-4745-abe3-ee55945934f8'
    elif echo $1 | grep -q "itms6shared20"
    then 
        auth="-u itms6shared20_cassandra_user_admin -p 2d30eca7-6a44-422d-80a9-1f50a03e046d"
    fi

    echo $CASSANDRA_HOME_DIR
    $CASSANDRA_HOME_DIR/bin/cqlsh $host 9160 $keyspace $auth
}

cqlqa_sharded() {
    if [ $# -eq 0 ]
    then
        echo "clusterName required. Try \"cqlqa itms8shared20 keyspace\". keyspace is optional"
        return
    fi

    echo "http://casserole.vp.if1.apple.com/api/v1/cluster_endpoints?appscope=$1&cluster=$1_s$3&dc=DC1"

    local host=$(cassandraHostFetcher "http://casserole.vp.if1.apple.com/api/v1/cluster_endpoints?appscope=$1&cluster=$1_s$3&dc=DC1")
    local auth=''
    local keyspace=''
    
    if [ $# -gt 2 ] 
    then 
        keyspace="-k"$2
    fi


    if echo $1 | grep -q "itms9shared20"
    then 
        auth='-u itms9shared20_cassandra_user_admin -p 863D621E-BD2F-4642-B530-1C4D38B2EA07'
    elif echo $1 | grep -q "itms11shared20"
    then 
        auth='-u itms11shared20_cassandra_user_admin -p 27D621D2-F2A8-4AC4-A4BC-5D678AED12F9'
    elif echo $1 | grep -q "itms8shared20"
    then 
        auth='-uitms8shared20_amprecommendations_cassandra_user_admin -pFB7BAEDD-8EAF-4688-B210-0B7844A7CF17'
    fi

    echo $CASSANDRA_HOME_DIR
    echo $CASSANDRA_HOME_DIR/bin/cqlsh $host 9042 $keyspace $auth
    $CASSANDRA_HOME_DIR/bin/cqlsh $host 9042 $keyspace $auth
}

recophlpoc () {
    OPTIND=1
    local port=9160
    local user=amprecopoc_cassandra_user_admin
    local password=35A19273-93AF-48D5-9A86-0E3E6ED6821F

    while getopts ":u:p:i" opt; do
        case $opt in
    
            u) user=$OPTARG
                    ;;
            p) password=$OPTARG
                     ;;
            i) ignoreKeyspace=true
                    ;;
        esac
    done

    local casserole_ep='http://casserole.pv.if.apple.com/api/v2/amprecopoc/cluster-endpoints?appscope=amprecopoc&cluster=amprecopoc&dc=PV'
    local host=$(curl -s $casserole_ep 2>&1 | sed 's/,.*//')
    echo $host
    pvTunnel $port $host
    local keyspace=its_apps_reco
       
    if [ "$ignoreKeyspace" = true ]; then
        $CASSANDRA_HOME_DIR/bin/cqlsh localhost $port -u $user -p $password
        return
    fi

 
    if [ $# -eq 1 ]
    then
        echo "connecting to keyspace $1"
        keyspace=$1
    fi

    $CASSANDRA_HOME_DIR/bin/cqlsh localhost $port -u $user -p $password
}

recovideo () {
    OPTIND=1
    local port=9162
    local user=amprecovideo_cassandra_user_admin
    local password=2651B699-CA3A-4264-8C20-FE51B3153452

    while getopts ":u:p:i" opt; do
        case $opt in
    
            u) user=$OPTARG
                    ;;
            p) password=$OPTARG
                     ;;
            i) ignoreKeyspace=true
                    ;;
        esac
    done

    local host=$(cassandraHostFetcher 'http://casserole.st.if.apple.com/api/v1/cluster_endpoints?appscope=amprecovideo&cluster=amprecovideo&dc=ST')
    echo $host
    prodTunnel $port $host
    local keyspace=its_apps_reco
       
    if [ "$ignoreKeyspace" = true ]; then
        $CASSANDRA_HOME_DIR/bin/cqlsh localhost $port -u $user -p $password
        return
    fi

 
    if [ $# -eq 1 ]
    then
        echo "connecting to keyspace $1"
        keyspace=$1
    fi
    $CASSANDRA_HOME_DIR/bin/cqlsh localhost $port -k $keyspace -u $user -p $password --ssl
}

videoreco () {
    OPTIND=1
    local port=9160
    local user=amprecovideo_cassandra_user_admin
    local password=2651B699-CA3A-4264-8C20-FE51B3153452

    while getopts ":u:p:i" opt; do
        case $opt in
    
            u) user=$OPTARG
                    ;;
            p) password=$OPTARG
                     ;;
            i) ignoreKeyspace=true
                    ;;
        esac
    done

    local host=$(cassandraHostFetcher 'http://casserole.nk.if.apple.com/api/v1/cluster_endpoints?appscope=amprecovideo&cluster=amprecovideo&dc=ST')
    echo $host
    prodTunnel $port $host
    local keyspace=its_apps_reco
       
    if [ "$ignoreKeyspace" = true ]; then
        $CASSANDRA_HOME_DIR/bin/cqlsh localhost $port -u $user -p $password
        return
    fi

 
    if [ $# -eq 1 ]
    then
        echo "connecting to keyspace $1"
        keyspace=$1
    fi

    echo $CASSANDRA_HOME_DIR
    echo $CASSANDRA_HOME_DIR/bin/cqlsh $host 9160 $keyspace -u $user -p $password --ssl
    $CASSANDRA_HOME_DIR/bin/cqlsh localhost $port -k $keyspace -u $user -p $password --ssl
}

itmsreco () {
    OPTIND=1
    local port=9160
    local user=itmsreco_cassandra_user
    local password=686765D7-06D5-46D3-A64F-6CF329EA468D

    while getopts ":u:p:i" opt; do
        case $opt in
    
            u) user=$OPTARG
                    ;;
            p) password=$OPTARG
                     ;;
            i) ignoreKeyspace=true
                    ;;
        esac
    done

    local host=$(cassandraHostFetcher 'http://casserole.nk.if.apple.com/api/v1/cluster_endpoints?appscope=itmsreco&cluster=itmsreco&dc=ST')
    echo $host
    prodTunnel $port $host
    local keyspace=its_apps_reco
       
    if [ "$ignoreKeyspace" = true ]; then
        $CASSANDRA_HOME_DIR/bin/cqlsh localhost $port -u $user -p $password
        return
    fi

 
    if [ $# -eq 1 ]
    then
        echo "connecting to keyspace $1"
        keyspace=$1
    fi

    $CASSANDRA_HOME_DIR/bin/cqlsh localhost $port -k $keyspace -u $user -p $password
}

itmsreco_su(){
    OPTIND=1
    local port=9160
    local user=itmsreco_cassandra_user_admin
    local password=143DF7F7-5418-4EA7-A08C-3556746DD4C8

    while getopts ":u:p:i" opt; do
        case $opt in
    
            u) user=$OPTARG
                    ;;
            p) password=$OPTARG
                     ;;
            i) ignoreKeyspace=true
                    ;;
        esac
    done

    local host=$(cassandraHostFetcher 'http://casserole.nk.if.apple.com/api/v1/cluster_endpoints?appscope=itmsreco&cluster=itmsreco&dc=ST')
    echo $host
    prodTunnel $port $host
    local keyspace=its_apps_reco
       
    if [ "$ignoreKeyspace" = true ]; then
        $CASSANDRA_HOME_DIR/bin/cqlsh localhost $port -u $user -p $password
        return
    fi

 
    if [ $# -eq 1 ]
    then
        echo "connecting to keyspace $1"
        keyspace=$1
    fi

    $CASSANDRA_HOME_DIR/bin/cqlsh localhost $port -k $keyspace -u $user -p $password
}

recoapps () {
    local user=amprecoapps_cassandra_user_readonly
    local password=D2BE2534-7FEF-4AAB-A9FA-BE0273C4678C
    connect_recoapps $user $password
}

recoapps_rw () {
    local user=amprecoapps_cassandra_user_admin
    local password=15C8C9C5-9DF6-41D1-B0EB-C3415F748A7C
    connect_recoapps $user $password
}

connect_recoapps () {
    OPTIND=1
    local port=9162
    local user=$1
    local password=$2

    while getopts ":u:p:i" opt; do
        case $opt in
    
            u) user=$OPTARG
                    ;;
            p) password=$OPTARG
                     ;;
            i) ignoreKeyspace=true
                    ;;
        esac
    done

    local host=$(cassandraHostFetcher 'http://casserole.st.if.apple.com/api/v1/cluster_endpoints?appscope=amprecoapps&cluster=amprecoapps&dc=ST')
    echo $host
    prodTunnel $port $host
    local keyspace=its_apps_reco
       
    if [ "$ignoreKeyspace" = true ]; then
        $CASSANDRA_HOME_DIR/bin/cqlsh localhost $port -u $user -p $password
        return
    fi

 
    if [ $# -eq 1 ]
    then
        echo "connecting to keyspace $1"
        keyspace=$1
    fi

    echo "Tunnening"
    $CASSANDRA_HOME_DIR/bin/cqlsh localhost $port -u $user -p $password
}

cassandraHostFetcher(){
    local host=$(curl -s $1 2>&1 | sed 's/:9160.*//')
    echo $host
}

prodTunnel() {
    createSshTunnel -l $1 -r 9042 -h $2 -p stgateway
}

pvTunnel() {
    createSshTunnel -l $1 -r 9160 -h $2 -p pvbastion
}

createSshTunnel() {
    OPTIND=1
    
    local lport=""
    local rhost=""
    local rport=""
    local proxyHost=""
    
    while getopts ":l:r:h:p:" opt; do
        case $opt in
    
            l) lport=$OPTARG
                    ;;
            r) rport=$OPTARG
                    ;;
            h) rhost=$OPTARG
                    ;;
            p) proxyHost=$OPTARG
                     ;;
        esac
    done

    local pids=`ps -A | grep -e '-L '$lport | grep -v 'grep' | awk '{print $1}' | xargs`
    if [ -n "$pids" ]
    then 
        kill $pids
        echo 'killing ssh tunnels that were open before'
        sleep 2
    fi


    ssh -fNo ExitOnForwardFailure=yes -L $lport:$rhost:$rport $proxyHost
}

